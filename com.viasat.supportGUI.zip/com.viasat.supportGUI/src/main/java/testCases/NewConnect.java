package testCases;

import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import util.BrowserFactory;
import util.Utilities;

public class NewConnect {
	
	public WebDriver driver;
	
	public Workbook workbook;
	
	public static String baseUrl = "https://ordermgmt.test.exede.net/PublicGUI-SupportGUI/v1/login.xhtml"; 
	
	@Parameters({"browser", "salesChannel"})
	@BeforeTest
	public void beforeTest(String browser, String salesChannel){
		try {
			 if(browser.equalsIgnoreCase("chrome")){
			        driver = BrowserFactory.startBrowser("chrome", baseUrl);
			    }
			    else if(browser.equalsIgnoreCase("ie")){
			        driver = BrowserFactory.startBrowser("ie", baseUrl);
			    }
			    else{
			        driver = BrowserFactory.startBrowser("firefox", baseUrl);
			    }
			 
			 	System.out.println("before test");
			 	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.workbook = Utilities.loadExcelFile("Addresses.xlsx");
	}
	
	@AfterTest
	public void afterTest(){
		System.out.println("after test");
		driver.quit();
		
	}
	
	@Test(priority=1)
	public void testA(){
		
		System.out.println("testA");
		
	}
	
	@Test(priority=2)
	public void testB(){
		
		System.out.println("testB");
	}
	
	@Test(priority=3)
	public void testC(){
		
		System.out.println("testC");
	}
	
	@Test(priority=4)
	public void testD(){
		
		System.out.println("testD");
	}
}

//System.setProperty("webdriver.chrome.driver", "C:\\Users\\spark\\workspace\\com.viasat.supportGUI\\resources\\drivers\\chromedriver.exe");
//
//WebDriver driver = new ChromeDriver();
//
//driver.get("http://www.google.com");
