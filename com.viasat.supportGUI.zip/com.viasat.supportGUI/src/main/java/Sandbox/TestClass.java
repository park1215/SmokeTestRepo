package Sandbox;

public class TestClass {

	public String printString(){
		return "Hello World";
	}
}
