package Sandbox;

public class UtilitiesTest {



//	 WebDriverWait wait = new WebDriverWait(driver, 10);
//
//	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.id(>someid>)));
//	1
//	2
//	3
//	 WebDriverWait wait = new WebDriverWait(driver, 10);
//	 
//	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.id(>someid>)));
	
//	***FluentWait
//	 // for its presence once every 5 seconds.
//	 
//	  Wait wait = new FluentWait(driver)
//	 
//	    .withTimeout(30, SECONDS)
//	 
//	    .pollingEvery(5, SECONDS)
//	 
//	    .ignoring(NoSuchElementException.class);
//	 
//	  WebElement foo = wait.until(new Function() {
//	 
//	    public WebElement apply(WebDriver driver) {
//	 
//	    return driver.findElement(By.id("foo"));
//	 
//	    }
//	 
//	   });
}
