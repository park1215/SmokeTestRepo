package jUnit;

import static org.junit.Assert.*;

import org.testng.annotations.Test;

import Sandbox.TestClass;

public class TestClassTest {

	@Test
	public void test() {

		TestClass tc = new TestClass();
		
		String expected = "Hello World";
		
		assertTrue(expected.equals(tc.printString()));
	}

}
