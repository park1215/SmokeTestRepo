package testCases;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import util.BrowserFactory;
import util.Utilities;
import java.util.Properties;

public class NewConnect {
	
	public WebDriver driver;
	
	public Workbook workbook;
	
	public static String baseUrl ="https://ordermgmt.test.exede.net/PublicGUI-SupportGUI/v1/pages/addcustomer/serviceAvailability.xhtml"; 
	
	public Properties prop;
	
	@Parameters({"browser", "salesChannel"})
	@BeforeTest
	public void beforeTest(String browser, String salesChannel){
		try {
			 if(browser.equalsIgnoreCase("chrome")){
			        driver = BrowserFactory.startBrowser("chrome", baseUrl);
			    }
			    else if(browser.equalsIgnoreCase("ie")){
			        driver = BrowserFactory.startBrowser("ie", baseUrl);
			    }
			    else{
			        driver = BrowserFactory.startBrowser("firefox", baseUrl);
			    }
			 
			 	
			 	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.workbook = Utilities.loadExcelFile("Addresses.xlsx");
		this.prop = Utilities.loadPropertyFile("SupportGUI.properties");
		
		this.baseUrl = prop.getProperty("https://ordermgmt.test.exede.net/PublicGUI-SupportGUI/v1/pages/addcustomer/serviceAvailability.xhtml");
		
		
		System.out.println("SupportGUI URL : " + baseUrl);
		System.out.println("before test");
		
	}
	
	@AfterTest
	public void afterTest(){
		System.out.println("after test");
//		driver.quit();
		
	}
	
	@Parameters("salesChannel")
	@Test(priority=1)
	public void testA(String salesChannel){
		
		int currentRow = 1;

		Sheet workSheet = this.workbook.getSheet(salesChannel);
		
		int endRow = workSheet.getLastRowNum();
		
		System.out.println("endRow : " + endRow);
		
		int endCell = workSheet.getRow(currentRow).getLastCellNum();
		
		System.out.println("endCell : " + endCell);
		
		Map<String, String> dataMap = Utilities.getRowCellMap(workSheet, currentRow);
		
		Set<String> set = dataMap.keySet();
		
		for(String key : dataMap.keySet()){
			System.out.println(key + " - " + dataMap.get(key));
		}
		
		String username = dataMap.get("Username");

	    String password = dataMap.get("Password");

	    String salesChannelq = dataMap.get("SalesChannel");

	    String customerType = dataMap.get("CustomerType");

	    String salesChannelType = dataMap.get("SalesChannelType");

	    String addressLine1 = dataMap.get("AddressLine1");

	    String firstName = dataMap.get("FirstName");

	    String lastName = dataMap.get("LastName");

	    String city = dataMap.get("City");

	    String state = dataMap.get("State");

	    String zipCode = dataMap.get("Zip");

	    String voipIncluded = dataMap.get("VoIPIncluded");

	    String voipMac = dataMap.get("VoIPMac");

	    String provisionModem = dataMap.get("provisionModem");

	    String activateVoIP = dataMap.get("activateVoIP");

	    String latitude = dataMap.get("Lat");

	    System.out.println("Latitude : " + latitude);

		String longitude = dataMap.get("Long");

	    System.out.println("Longitude : " + longitude);

	    String transactionType = dataMap.get("TransactionType");

	    Boolean includeVoip = false;
	    
		if (!voipIncluded.equalsIgnoreCase("no")){
	        includeVoip = true;
		}
			
		Boolean modemProvision = false;
		
	    if (!provisionModem.equalsIgnoreCase("no")){
	    	modemProvision = true;
	    }

	    Boolean voipActivation = false;
	    
	    if(!activateVoIP.equalsIgnoreCase("no")){
	    	voipActivation = true;
	    }
		    
	    System.out.println("voip is included in this order? : " + voipActivation.toString());

		String paymentType = dataMap.get("PaymentType");

		String packageName = dataMap.get("Package");

		String satelliteName = dataMap.get("Satellite");

		System.out.println("Payment type in the data table: " + paymentType);

		System.out.println("Package Name : " + packageName);

		System.out.println("Satellite Name : " + satelliteName);
		
		driver.findElement(By.xpath("//*[@id='document:body']/table/tbody/tr[2]/td/form/table/tbody/tr[3]/td[2]/input")).sendKeys(username);

		driver.findElement(By.xpath("//*[@id='document:body']/table/tbody/tr[2]/td/form/table/tbody/tr[4]/td[2]/input")).sendKeys(password);
		
		driver.findElement(By.name("submit")).click();
		
		System.out.println("testA");
	}
	
	@Test(priority=2)
	public void testB(){
		
		System.out.println("testB");
	}
	
	@Test(priority=3)
	public void testC(){
		
		System.out.println("testC");
	}
	
	@Test(priority=4)
	public void testD(){
		
		System.out.println("testD");
	}
}

//System.setProperty("webdriver.chrome.driver", "C:\\Users\\spark\\workspace\\com.viasat.supportGUI\\resources\\drivers\\chromedriver.exe");
//
//WebDriver driver = new ChromeDriver();
//
//driver.get("http://www.google.com");
